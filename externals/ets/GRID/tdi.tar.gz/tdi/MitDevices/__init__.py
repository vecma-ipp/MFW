"""
MitDevices
==========

@authors: Tom Fredian(MIT/USA), Josh Stillerman(MIT/USA)
@copyright: 2008
@license: GNU GPL



"""
from cp7452 import CP7452
